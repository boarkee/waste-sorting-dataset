# waste-sorting > 2023-04-20 12:21pm
https://universe.roboflow.com/cesar-nxztq/waste-sorting-e6aor

Provided by a Roboflow user
License: CC BY 4.0

